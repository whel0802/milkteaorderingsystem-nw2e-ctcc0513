/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaldsaloyd;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;
public class Que {
    public static  Queue<Integer> queue = new LinkedList<Integer>();
    static  int total;
    public void enqueue(int total){
        queue.add(total);
     this.total = total;
    }
    public void peek (){
        queue.peek();
    }
    public void dequeue(){
        if (queue.isEmpty()){
               JOptionPane.showMessageDialog(null,"No Order Found", "Information",JOptionPane.WARNING_MESSAGE );
        }else {
        queue.poll();
        }
    }
    public int calculateTotal() {
        int total = 0;

        for (Integer value : queue) {
            total += value;
        }

        return total;
    }
    public int Customersize(){
        int customers = 0;
         queue.size();
         return customers;
         
    }
}
