/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaldsaloyd;

import static finaldsaloyd.OrderServeFrame.queue;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User's
 */

public  class  MainMenu extends javax.swing.JFrame {
      int NCustomer = Printresip.customer;
    String product[] = {"TARO", "BSUGAR","MATCHA","CHOCO","GRAHAM","SBERRY"};
    String size[] = {"Small", "Medium", "Large"};
    JComboBox<String> sizeComboBox = new JComboBox<>(size);
    SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 100, 1);
    int items=0;
    int total;
    String  g = "";
    double price=0.0;
    public static Que queque = new Que();
    
    public MainMenu() {
        initComponents();
        
            //colors
            Color green = new Color(158,156,114);
            Color brown = new Color(222,199,176);
            Color pink = new Color(199,145,121);
            Color cream2 = new Color(232,224,216);
            Color cream = new Color (225,219,213);
            
            //customize scrollbar
            jScrollPane1.getVerticalScrollBar().setUI(new BasicScrollBarUI() {    
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = green ;
                this.thumbHighlightColor = Color.WHITE;
                this.thumbDarkShadowColor = Color.darkGray;
                this.trackColor = cream;
            }
            
            @Override
            protected JButton createDecreaseButton(int orientation) {
                JButton button = super.createDecreaseButton(orientation);
                button.setBackground(green);
                return button;
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                JButton button = super.createIncreaseButton(orientation);
                button.setBackground(green);
                return button;
            }
        });
             jScrollPane2.getVerticalScrollBar().setUI(new BasicScrollBarUI() {    
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = green ;
                this.thumbHighlightColor = Color.WHITE;
                this.thumbDarkShadowColor = Color.darkGray;
                this.trackColor = cream;
            }
            
            @Override
            protected JButton createDecreaseButton(int orientation) {
                JButton button = super.createDecreaseButton(orientation);
                button.setBackground(green);
                return button;
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                JButton button = super.createIncreaseButton(orientation);
                button.setBackground(green);
                return button;
            }
        });
            
            //image buttons
            ImageIcon taro = new ImageIcon("Image\\1.png");
            ImageIcon matcha = new ImageIcon("Image\\2.png");
            ImageIcon choco = new ImageIcon("Image\\3.png");
            ImageIcon mango = new ImageIcon("Image\\4.png");
            ImageIcon berry = new ImageIcon("Image\\5.png");
            ImageIcon sugar = new ImageIcon("Image\\6.png");
            ImageIcon logo = new ImageIcon("Image\\7.png");
            jButton1.setIcon(resizeIcon(taro, jButton1.getWidth() , jButton1.getHeight()));
            jButton7.setIcon(resizeIcon(matcha, jButton7.getWidth() , jButton7.getHeight()));
            jButton8.setIcon(resizeIcon(choco, jButton8.getWidth() , jButton8.getHeight()));
            jButton9.setIcon(resizeIcon(mango, jButton9.getWidth() , jButton9.getHeight()));
            jButton10.setIcon(resizeIcon(berry, jButton10.getWidth() , jButton10.getHeight()));
            jButton12.setIcon(resizeIcon(sugar, jButton12.getWidth() , jButton12.getHeight()));      
            
            jTable1.getTableHeader().setFont(new Font("Segoe UI", Font. BOLD, 16));
            jTable1.getTableHeader().setOpaque (false);
            jTable1.getTableHeader().setBackground (new Color(154,169,132));
           
    }
    void deque (){
        queque.dequeue();
    }
     void print (){
        queque.peek();
        
    }
     void Rtotal(){
         queque.calculateTotal();
     }
     
    void Table(String product){
        JSpinner quantitySpinner = new JSpinner(spinnerModel);
        String selectedSize;
        JComboBox<String> sizeComboBox = new JComboBox<>(size);
        quantitySpinner.setValue(1);
        int result = JOptionPane.showConfirmDialog(this,new Object[]{new JLabel("Size:"), sizeComboBox, new JLabel("Quantity:"), quantitySpinner},"Select Size and Quantity",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        DefaultTableModel tb = (DefaultTableModel ) jTable1.getModel();
        
        if (result == JOptionPane.OK_OPTION) {
            selectedSize = (String) sizeComboBox.getSelectedItem();
            int selectedQuantity = (int) quantitySpinner.getValue();
            
            if(selectedSize.equalsIgnoreCase("large")){
                int total = selectedQuantity * 79;
                    tb.addRow(new Object[]{product, selectedSize, selectedQuantity,total});
            } else if (selectedSize.equalsIgnoreCase("Medium")){
                    int total = selectedQuantity * 69;
                tb.addRow(new Object[]{product, selectedSize, selectedQuantity,total});
            } else {
                int total = selectedQuantity * 59;
                tb.addRow(new Object[]{product, selectedSize, selectedQuantity,total});
            }
        }
        
        
        
    }
    private static Icon resizeIcon(ImageIcon icon, int resizedWidth, int resizedHeight) {
        
        Image img = icon.getImage();  
        Image resizedImage = img.getScaledInstance(resizedWidth, resizedHeight,  java.awt.Image.SCALE_SMOOTH);  
        return new ImageIcon(resizedImage);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Milktea Shop");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(221, 208, 196));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setToolTipText("");
        jScrollPane1.setViewportBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(107, 131, 82)));
        jScrollPane1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(4, 4));
        jScrollPane1.setRequestFocusEnabled(false);
        jScrollPane1.setVerifyInputWhenFocusTarget(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(158, 156, 114)));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 31, 150, 150));

        jButton7.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 207, 150, 150));

        jButton8.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 31, 150, 150));

        jButton9.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 207, 150, 150));

        jButton10.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 385, 150, 150));

        jButton12.setMinimumSize(new java.awt.Dimension(0, 0));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 385, 150, 150));

        jScrollPane1.setViewportView(jPanel2);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 380, 480));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setBackground(new java.awt.Color(154, 169, 132));
        jLabel3.setFont(new java.awt.Font("Gill Sans MT Ext Condensed Bold", 1, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(158, 156, 114));
        jLabel3.setText("MILKTEA");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addContainerGap(684, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 820, 80));

        jScrollPane2.setBackground(new java.awt.Color(255, 204, 204));
        jScrollPane2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane2.setForeground(new java.awt.Color(232, 224, 216));
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setMaximumSize(new java.awt.Dimension(352, 60));
        jScrollPane2.setPreferredSize(new java.awt.Dimension(352, 60));

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));
        jPanel5.setForeground(new java.awt.Color(232, 224, 216));
        jPanel5.setPreferredSize(new java.awt.Dimension(380, 600));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product", "Size", "Qty.", "Total"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable1);

        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 600));

        jScrollPane2.setViewportView(jPanel5);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, 400, 480));

        jButton4.setBackground(new java.awt.Color(158, 156, 114));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setText("BACK");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 630, 110, 30));

        jButton2.setBackground(new java.awt.Color(158, 156, 114));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("DELETE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 670, 110, 30));

        jButton3.setBackground(new java.awt.Color(158, 156, 114));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setText("CONFIRM");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 630, 110, 30));

        jLabel4.setBackground(new java.awt.Color(154, 169, 132));
        jLabel4.setFont(new java.awt.Font("Myanmar Text", 1, 23)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(158, 156, 114));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Small - 59 Medium - 69 Large - 79");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 630, 380, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 920, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 738, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
//BUTTON 2
Table(product[1]);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
Table(product[0]);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
//BUTTON 3
Table(product[2]);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
//BUTTON 4   
Table(product[3]);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
//BUTTON 5
Table(product[4]);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
// BUTTON 6
Table(product[5]);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
DefaultTableModel tb = (DefaultTableModel ) jTable1.getModel();
int row =jTable1.getSelectedRow();
String rawr = tb.getValueAt(row, 3).toString();
// TODO add your handling code here:

    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
       DefaultTableModel tb = (DefaultTableModel ) jTable1.getModel();
        int rows = tb.getRowCount();
        if (rows<=0){
         JOptionPane.showMessageDialog(null,"Empty Order", "Information",JOptionPane.WARNING_MESSAGE );
        } else if(jTable1.getSelectionModel().isSelectionEmpty()){
            JOptionPane.showMessageDialog(null,"Select an Item to Remove", "Information",JOptionPane.WARNING_MESSAGE);
        }
        else{
            tb.removeRow(jTable1.getSelectedRow());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            DefaultTableModel tb = (DefaultTableModel ) jTable1.getModel();
           
            int nCustomer;
            double totalPrice  = 0.0;
            if(tb.getRowCount()==0){
                JOptionPane.showMessageDialog(null,"No Order Found", "Information",JOptionPane.WARNING_MESSAGE );
            }else{
        for (int i=0; i<tb.getRowCount(); i++){     
                 g = ( g +"["+tb.getValueAt(i, 2).toString() +"] "+ tb.getValueAt(i, 0).toString() + "\t\t" + tb.getValueAt(i, 1).toString() +"\t\t"+tb.getValueAt(i, 3).toString() +"\n");   
                 price = Double.valueOf(tb.getValueAt(i, 3).toString()) ;
                 totalPrice  += price;
                 String item;
                 items = Integer.valueOf(tb.getValueAt(i, 2).toString()) ;
                 total += items;
            }
        Printresip res  = new Printresip (g,total,totalPrice);  
        Receipt resip = new Receipt ();
       setVisible(false);
       resip.setVisible(true);
            }
    
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
              NCustomer= NCustomer-1;
        
        Printresip res = new Printresip(NCustomer,0); //for decrement
        OrderServeFrame l = new OrderServeFrame();
        l.setVisible(true);
        setVisible(false);

     
    }//GEN-LAST:event_jButton4ActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new OrderServeFrame().setVisible(true);
                //To open Login frame first by default
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
