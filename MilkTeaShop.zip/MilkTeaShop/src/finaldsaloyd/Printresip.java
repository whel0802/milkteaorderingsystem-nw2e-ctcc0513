/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaldsaloyd;

public  class Printresip {
   static  String g;
   static int total = 0;
   static int customer;
  static double price = 0;
    Printresip(String g,int total,double price){
        this.g = g;
        this.total = total;
        this.price = price;
     
    }
    Printresip(int customer){ // for increase customer number
         customer++;
    this.customer = customer;
    } 
    Printresip(int Customer, int checker){ // for decrease customer number
        customer--;
        this.customer = customer;
    }
}
